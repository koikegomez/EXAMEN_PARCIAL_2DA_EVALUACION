
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Carlos Herrera
 */
public class PRINCIPAL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner (System.in);
        boolean VasBien = true;
        String gohan,g,o,h,a,n,video,v,i,d,e,perrotote,f,t,potter,p,r,tec,c,caracter;
        int palabra,contador=0;
        g="_";o="_";h="_";a="_";n="_";v="_";e="_";d="_";i="_";f="_";t="_";p="_";r="_";c="_";
        palabra = (int) (Math.random() * 5) + 1;
        if (palabra == 1){
            
            System.out.println("La palabra tiene 5 caracteres");
 System.out.println("Escribe un caracter");
           
         
           while (VasBien){  
                            
                         caracter = input.nextLine();
               if (caracter.equals("g")){
                   g = "g";
                       System.out.print("palabra 5 letras    "); 
               } else if (caracter.equals("o")){
                   o = "o";
                       System.out.print("palabra 5 letras    "); 
                   }
                else if (caracter.equals("h")){
                   h = "h";
                       System.out.print("palabra 5 letras    "); 
                 
                }else if (caracter.equals("a")){
                   a = "a";
                       System.out.print("palabra 5 letras    "); 
                   
           }else if (caracter.equals("n")){
                   n = "n";
                       System.out.print("palabra 5 letras    "); 
                 
                   
           } else  System.out.print("palabra 5 letras    "); System.out.println(g+o+h+a+n);
                        contador++; 
                        System.out.println("  ___ _");
                    if (contador ==1){
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");} 
                    else if (contador == 2){
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       ");System.out.println("(2do intento)");}
                    else if (contador == 3){  
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       ");System.out.println("(2do intento)");
                   System.out.print("  | ");  System.out.print("---    ");System.out.println("(3er intento)");}
                    else if (contador == 4){  
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       "); System.out.println("(2do intento)");
                   System.out.print("  | ");   System.out.print("---     "); System.out.println("(3er intento)");
                   System.out.print("  |  ");  System.out.print("|      "); System.out.println("(4to intento)");}
                    else if (contador == 5){ 
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       "); System.out.println("(2do intento)");
                   System.out.print("  | ");   System.out.print("---     "); System.out.println("(3er intento)");
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(4to intento)");
                   System.out.print("  | ");  System.out.print("| "); System.out.print("|       "); System.out.println("(5to intento)");
                   System.out.println("  |  "); 
                   System.out.print("__"); System.out.print("|");System.out.print("_");System.out.print("_");System.out.print("_");System.out.println("_");}
                       else  {
                           System.out.println("muerto x.x");}
}
           
                     
        }      else   if (palabra == 2){
            
            System.out.println("La palabra tiene 5 caracteres");
            System.out.println("Escribe un caracter");
           
         
           while (VasBien){  
                 
                         caracter = input.nextLine();
               if (caracter.equals("v")){
                   v = "v";
                       System.out.print("palabra 5 letras    "); 
               } else if (caracter.equals("i")){
                   i = "i";
                       System.out.print("palabra 5 letras    "); 
                   }
                else if (caracter.equals("d")){
                   d = "d";
                       System.out.print("palabra 5 letras    "); 
                 
                }else if (caracter.equals("e")){
                   e = "e";
                       System.out.print("palabra 5 letras    "); 
                   
           }else if (caracter.equals("o")){
                   o = "o";
                       System.out.print("palabra 5 letras    "); 
                 
                   
           } else  System.out.print("palabra 5 letras    "); System.out.println(v+i+d+e+o);
                        contador++; 
                        System.out.println("  ___ _");
                    if (contador ==1){
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");} 
                    else if (contador == 2){
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       ");System.out.println("(2do intento)");}
                    else if (contador == 3){  
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       ");System.out.println("(2do intento)");
                   System.out.print("  | ");  System.out.print("---    ");System.out.println("(3er intento)");}
                    else if (contador == 4){  
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       "); System.out.println("(2do intento)");
                   System.out.print("  | ");   System.out.print("---     "); System.out.println("(3er intento)");
                   System.out.print("  |  ");  System.out.print("|      "); System.out.println("(4to intento)");}
                    else if (contador == 5){ 
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       "); System.out.println("(2do intento)");
                   System.out.print("  | ");   System.out.print("---     "); System.out.println("(3er intento)");
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(4to intento)");
                   System.out.print("  | ");  System.out.print("| "); System.out.print("|       "); System.out.println("(5to intento)");
                   System.out.println("  |  "); 
                   System.out.print("__"); System.out.print("|");System.out.print("_");System.out.print("_");System.out.print("_");System.out.println("_");}
                       else  {
                           System.out.println("muerto x.x");}
}
           
                     
        }  if (palabra == 3){
            
            System.out.println("La palabra tiene 6 caracteres");
            System.out.println("Escribe un caracter");
           
         
           while (VasBien){  
                 
                         caracter = input.nextLine();
               if (caracter.equals("p")){
                   p = "p";
                       System.out.print("palabra 6 letras    "); 
               } else if (caracter.equals("o")){
                   o = "o";
                       System.out.print("palabra 6 letras    "); 
                   }
                else if (caracter.equals("t")){
                   t = "t";
                       System.out.print("palabra 6 letras    "); 
                 
                }else if (caracter.equals("e")){
                   e = "e";
                       System.out.print("palabra 6 letras    "); 
                   
           }else if (caracter.equals("r")){
                   r = "r";
                       System.out.print("palabra 6 letras    "); 
                 
                   
           } else  System.out.print("palabra 5 letras    "); System.out.println(p+o+t+t+e+r);
                        contador++; 
                        System.out.println("  ___ _");
                    if (contador ==1){
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");} 
                    else if (contador == 2){
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       ");System.out.println("(2do intento)");}
                    else if (contador == 3){  
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       ");System.out.println("(2do intento)");
                   System.out.print("  | ");  System.out.print("---    ");System.out.println("(3er intento)");}
                    else if (contador == 4){  
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       "); System.out.println("(2do intento)");
                   System.out.print("  | ");   System.out.print("---     "); System.out.println("(3er intento)");
                   System.out.print("  |  ");  System.out.print("|      "); System.out.println("(4to intento)");}
                    else if (contador == 5){ 
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       "); System.out.println("(2do intento)");
                   System.out.print("  | ");   System.out.print("---     "); System.out.println("(3er intento)");
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(4to intento)");
                   System.out.print("  | ");  System.out.print("| "); System.out.print("|       "); System.out.println("(5to intento)");
                   System.out.println("  |  "); 
                   System.out.print("__"); System.out.print("|");System.out.print("_");System.out.print("_");System.out.print("_");System.out.println("_");}
                       else  {
                           System.out.println("muerto x.x");}
}
           
                     
        }  if (palabra == 4){
            
            System.out.println("La palabra tiene 9 caracteres");
            System.out.println("Escribe un caracter");
           
         
           while (VasBien){  
                 
                         caracter = input.nextLine();
               if (caracter.equals("p")){
                   p = "p";
                       System.out.print("palabra 9 letras    "); 
               } else if (caracter.equals("e")){
                   e = "e";
                       System.out.print("palabra 9 letras    "); 
                   }
                else if (caracter.equals("r")){
                   r = "r";
                       System.out.print("palabra 9 letras    "); 
                 
                }else if (caracter.equals("o")){
                   o = "o";
                       System.out.print("palabra 9 letras    "); 
                   
           }else if (caracter.equals("t")){
                   t = "t";
                       System.out.print("palabra 9 letras    "); 
                 
                   
           } else  System.out.print("palabra 9 letras    "); System.out.println(p+e+r+r+o+t+o+t+e);
                        contador++; 
                        System.out.println("  ___ _");
                    if (contador ==1){
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");} 
                    else if (contador == 2){
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       ");System.out.println("(2do intento)");}
                    else if (contador == 3){  
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       ");System.out.println("(2do intento)");
                   System.out.print("  | ");  System.out.print("---    ");System.out.println("(3er intento)");}
                    else if (contador == 4){  
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       "); System.out.println("(2do intento)");
                   System.out.print("  | ");   System.out.print("---     "); System.out.println("(3er intento)");
                   System.out.print("  |  ");  System.out.print("|      "); System.out.println("(4to intento)");}
                    else if (contador == 5){ 
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       "); System.out.println("(2do intento)");
                   System.out.print("  | ");   System.out.print("---     "); System.out.println("(3er intento)");
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(4to intento)");
                   System.out.print("  | ");  System.out.print("| "); System.out.print("|       "); System.out.println("(5to intento)");
                   System.out.println("  |  "); 
                   System.out.print("__"); System.out.print("|");System.out.print("_");System.out.print("_");System.out.print("_");System.out.println("_");}
                       else  {
                           System.out.println("muerto x.x");}
}
           
                     
        } if (palabra == 5){
            
            System.out.println("La palabra tiene 3 caracteres");
            System.out.println("Escribe un caracter");
           
         
           while (VasBien){  
                 
                         caracter = input.nextLine();
               if (caracter.equals("t")){
                   t = "t";
                       System.out.print("palabra 5 letras    "); 
               } else if (caracter.equals("e")){
                   e = "e";
                       System.out.print("palabra 5 letras    "); 
                   }
                else if (caracter.equals("c")){
                   c = "c";
                       System.out.print("palabra 5 letras    "); 
                 
                }else if (caracter.equals("a")){
                   a = "a";
                       System.out.print("palabra 5 letras    "); 
                   
           }else if (caracter.equals("n")){
                   n = "n";
                       System.out.print("palabra 5 letras    "); 
                 
                   
           } else  System.out.print("palabra 5 letras    "); System.out.println(t+e+c);
                        contador++; 

                        System.out.println("  ___ _");
                    if (contador ==1){
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");} 
                    else if (contador == 2){
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       ");System.out.println("(2do intento)");}
                    else if (contador == 3){  
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       ");System.out.println("(2do intento)");
                   System.out.print("  | ");  System.out.print("---    ");System.out.println("(3er intento)");}
                    else if (contador == 4){  
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       "); System.out.println("(2do intento)");
                   System.out.print("  | ");   System.out.print("---     "); System.out.println("(3er intento)");
                   System.out.print("  |  ");  System.out.print("|      "); System.out.println("(4to intento)");}
                    else if (contador == 5){ 
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(1er intento)");
                   System.out.print("  |  ");  System.out.print("0       "); System.out.println("(2do intento)");
                   System.out.print("  | ");   System.out.print("---     "); System.out.println("(3er intento)");
                   System.out.print("  |  ");  System.out.print("|       "); System.out.println("(4to intento)");
                   System.out.print("  | ");  System.out.print("| "); System.out.print("|       "); System.out.println("(5to intento)");
                   System.out.println("  |  "); 
                   System.out.print("__"); System.out.print("|");System.out.print("_");System.out.print("_");System.out.print("_");System.out.println("_");}
                       else  {
                           System.out.println("muerto x.x");}
}
           
                     
        }                 

                   }
        
    }
  
    