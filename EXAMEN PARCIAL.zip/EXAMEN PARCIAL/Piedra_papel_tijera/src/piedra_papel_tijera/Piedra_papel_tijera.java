/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package piedra_papel_tijera;

import static java.lang.System.console;
import java.util.Scanner;

/**
 *
 * @author erinl
 */
public class Piedra_papel_tijera {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic her
           Scanner input = new Scanner(System.in);
         boolean Exit;
         System.out.println("¿Iniciar el juego?");
         Exit = input.nextBoolean();
        while (Exit == true) {            
            
        
                //Codigo inicio
                int Inicio = (int) ((Math.random()*2)+1);
                int Piedra = 1;
                int Papel = 2;
                int Tijera = 3;
                //Codigo Inicio de usuario
                if (Inicio == 1) {
                System.out.println("Inicia el usuario");
                System.out.println("¿Piedra(1), Papel(2) o Tijeras(3)?");
                int Respuesta = input.nextInt();
                String Res;
               if (Respuesta == 1) {
                Res = "Piedra";
            } else if (Respuesta == 2) {
                Res = "Papel";
            } else {
                Res = "Tijeras";
            }
               
               //Codigo del Ordenador
               int numero = (int) ((Math.random()*3)+1);
            String respuesta;
            if (numero == 1) {
                respuesta = "Piedra";
            } else if (numero == 2) {
                respuesta = "Papel";
            } else {
                respuesta = "Tijeras";
            }
            
            if (Respuesta == numero) {
                System.out.println(Respuesta + "vs" + numero + "Empate");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            } else if (Respuesta == 1 && numero == 2) {
                System.out.println(Respuesta + "vs" + numero + "Gana el ordenador");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            } else if (Respuesta == 2 && numero == 1) {
                System.out.println(Respuesta + "vs" + numero + "Gana el usuario");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            } else if (Respuesta == 2 && numero == 3) {
                System.out.println(Respuesta +"vs" + numero + "Gana el ordenador");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            } else if (Respuesta == 3 && numero == 2) {
                System.out.println(Respuesta + "vs" + numero +"Gana el usuario");
                                   System.out.println("Continuar?");
            Exit = input.nextBoolean(); 
            } else if (Respuesta == 1 && numero == 3) {
                System.out.println(Respuesta + "vs" + numero + "Gana el Usuario");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            } else if (Respuesta == 3 && numero == 1) {
                System.out.println(Respuesta + "vs" + numero + "Gana el ordenador");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
                }
                    
            if (Inicio == 2){
                }
                }  
            //Codigo de inicio del ordenador
            System.out.println("Inicia el ordenador");
            int numero = (int) ((Math.random()*3)+1);
            String respuesta;
            if (numero == 1) {
                respuesta = "Piedra";
            } else if (numero == 2) {
                respuesta = "Papel";
            } else {
                respuesta = "Tijeras";
            }
            //codigo Usuario
                System.out.println("¿Piedra(1), Papel(2) o Tijeras(3)?");
                int Respuesta = input.nextInt();
                String Res;
               if (Respuesta == 1) {
                Res = "Piedra";
            } else if (Respuesta == 2) {
                Res = "Papel";
            } else {
                Res = "Tijeras";
            }
      
               if (Respuesta == numero) {
                System.out.println(Respuesta + "vs" + numero + "Empate");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            } else if (Respuesta == 1 && numero == 2) {
                System.out.println(Respuesta + "vs" + numero + "Gana el ordenador");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            } else if (Respuesta == 2 && numero == 1) {
                System.out.println(Respuesta + "vs" + numero + "Gana el usuario");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            } else if (Respuesta == 2 && numero == 3) {
                System.out.println(Respuesta +"vs" + numero + "Gana el ordenador");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            } else if (Respuesta == 3 && numero == 2) {
                System.out.println(Respuesta + "vs" + numero +"Gana el usuario");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            } else if (Respuesta == 1 && numero == 3) {
                System.out.println(Respuesta + "vs" + numero + "Gana el Usuario");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            } else if (Respuesta == 3 && numero == 1) {
                System.out.println(Respuesta + "vs" + numero + "Gana el ordenador");
                                    System.out.println("Continuar?");
            Exit = input.nextBoolean();
            
                
                
                }
        }
    }
}

  