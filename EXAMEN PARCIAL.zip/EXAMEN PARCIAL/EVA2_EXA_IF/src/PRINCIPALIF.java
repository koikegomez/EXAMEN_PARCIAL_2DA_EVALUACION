
import java.util.Scanner;

/**
 *
 * @author Carlos Herrera
 */
public class PRINCIPALIF {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner input = new Scanner (System.in);
        String A,B,C,D,E,F,G,H,I,result,Seleccion,Inicio,TURNPC;
        
        boolean TerminarJuego = true , repe = false;
        int PC,PC2;
        A= "";
        B= "";
        C= "";
        D= "";
        E= "";
        F= "";
        G= "";
        H= "";
        I= "";
        int num;
        num = (int) (Math.random()*2)+1;
        System.out.println(num);
          System.out.println("Bienvenido al juego asi es el tablero :");
          System.out.println("   1  2  3");
          System.out.println("_____________");
          System.out.println("1 |   |   |   |");
          System.out.println("_____________");
          System.out.println("2 |   |   |   |");
          System.out.println("_____________");
          System.out.println("3 |   |   |   |");
          System.out.println("_____________");
          System.out.println("Di si para iniciar");
           Inicio = input.nextLine();
          if (num == 1){System.out.println("Tu empiezas");
         
         if  (Inicio.equals("si") ){
         
        while (TerminarJuego){
        Seleccion = input.nextLine();
         if (Seleccion.equals("Exit"))TerminarJuego = false;

         else if (Seleccion.equals("1,1")){
             
              A = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
       
             if (TURNPC.equals(Seleccion))repe = true;
          while (repe){
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
              System.out.println("DESPUES while "+TURNPC );
         if (!TURNPC.equals(Seleccion)) repe = false;

          }


         if (TURNPC.equals("1,1")){
          A= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         }else if (TURNPC.equals("1,2")){
                                          
                B= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                  }else if (TURNPC.equals("1,3")){
                                          
                C= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          }else if (TURNPC.equals("2,1")){
                                          
                D= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
            }
          else if (TURNPC.equals("2,2")){
                                          
                E= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }else if (TURNPC.equals("2,3")){
                                          
                F= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,1")){
                                          
                G= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,2")){
                                          
                H= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,3")){

                I= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }}
  
          else if (Seleccion.equals("1,2")){
              B = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                   PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
       
             if (TURNPC.equals(Seleccion))repe = true;
          while (repe){
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
              System.out.println("DESPUES while "+TURNPC );
         if (!TURNPC.equals(Seleccion)) repe = false;

          }


         if (TURNPC.equals("1,1")){
          A= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         }else if (TURNPC.equals("1,2")){
                                          
                B= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                  }else if (TURNPC.equals("1,3")){
                                          
                C= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          }else if (TURNPC.equals("2,1")){
                                          
                D= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
            }
          else if (TURNPC.equals("2,2")){
                                          
                E= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }else if (TURNPC.equals("2,3")){
                                          
                F= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,1")){
                                          
                G= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,2")){
                                          
                H= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,3")){

                I= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }}
  
          else if (Seleccion.equals("1,2")){
              B = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          }else if (Seleccion.equals("1,3")){
              
              C = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                   PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
       
             if (TURNPC.equals(Seleccion))repe = true;
          while (repe){
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
              System.out.println("DESPUES while "+TURNPC );
         if (!TURNPC.equals(Seleccion)) repe = false;

          }


         if (TURNPC.equals("1,1")){
          A= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         }else if (TURNPC.equals("1,2")){
                                          
                B= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                  }else if (TURNPC.equals("1,3")){
                                          
                C= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          }else if (TURNPC.equals("2,1")){
                                          
                D= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
            }
          else if (TURNPC.equals("2,2")){
                                          
                E= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }else if (TURNPC.equals("2,3")){
                                          
                F= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,1")){
                                          
                G= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,2")){
                                          
                H= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,3")){

                I= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           } 
            if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Win");
            }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
          
          
          
          
 
          
         }else if (Seleccion.equals("2,1")){
              D = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
                   PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
       
             if (TURNPC.equals(Seleccion))repe = true;
          while (repe){
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
              System.out.println("DESPUES while "+TURNPC );
         if (!TURNPC.equals(Seleccion)) repe = false;

          }


         if (TURNPC.equals("1,1")){
          A= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         }else if (TURNPC.equals("1,2")){
                                          
                B= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                  }else if (TURNPC.equals("1,3")){
                                          
                C= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          }else if (TURNPC.equals("2,1")){
                                          
                D= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
            }
          else if (TURNPC.equals("2,2")){
                                          
                E= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }else if (TURNPC.equals("2,3")){
                                          
                F= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,1")){
                                          
                G= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,2")){
                                          
                H= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,3")){

                I= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }
                     if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                        }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}}
 
          
          
         else if (Seleccion.equals("2,2") ){
              E = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                   PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
       
             if (TURNPC.equals(Seleccion))repe = true;
          while (repe){
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
              System.out.println("DESPUES while "+TURNPC );
         if (!TURNPC.equals(Seleccion)) repe = false;

          }


         if (TURNPC.equals("1,1")){
          A= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         }else if (TURNPC.equals("1,2")){
                                          
                B= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                  }else if (TURNPC.equals("1,3")){
                                          
                C= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          }else if (TURNPC.equals("2,1")){
                                          
                D= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
            }
          else if (TURNPC.equals("2,2")){
                                          
                E= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }else if (TURNPC.equals("2,3")){
                                          
                F= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,1")){
                                          
                G= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,2")){
                                          
                H= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,3")){

                I= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }
                     if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                        }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}}
         
         
         
            else if (Seleccion.equals("2,3")){
              F = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                   PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
       
             if (TURNPC.equals(Seleccion))repe = true;
          while (repe){
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
              System.out.println("DESPUES while "+TURNPC );
         if (!TURNPC.equals(Seleccion)) repe = false;

          }


         if (TURNPC.equals("1,1")){
          A= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         }else if (TURNPC.equals("1,2")){
                                          
                B= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                  }else if (TURNPC.equals("1,3")){
                                          
                C= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          }else if (TURNPC.equals("2,1")){
                                          
                D= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
            }
          else if (TURNPC.equals("2,2")){
                                          
                E= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }else if (TURNPC.equals("2,3")){
                                          
                F= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,1")){
                                          
                G= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,2")){
                                          
                H= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,3")){

                I= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }
                        if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Win");
                        }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}}

          
          
          
          
          
          
          
          
          
          
          
          
           else if (Seleccion.equals("3,1")){
              G = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                   PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
       
             if (TURNPC.equals(Seleccion))repe = true;
          while (repe){
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
              System.out.println("DESPUES while "+TURNPC );
         if (!TURNPC.equals(Seleccion)) repe = false;

          }


         if (TURNPC.equals("1,1")){
          A= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         }else if (TURNPC.equals("1,2")){
                                          
                B= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                  }else if (TURNPC.equals("1,3")){
                                          
                C= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          }else if (TURNPC.equals("2,1")){
                                          
                D= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
            }
          else if (TURNPC.equals("2,2")){
                                          
                E= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }else if (TURNPC.equals("2,3")){
                                          
                F= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,1")){
                                          
                G= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,2")){
                                          
                H= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,3")){

                I= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }
                       if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Win");
                        }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}}

  
          
          
          else if (Seleccion.equals("3,2")){
              H = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                   PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
       
             if (TURNPC.equals(Seleccion))repe = true;
          while (repe){
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
              System.out.println("DESPUES while "+TURNPC );
         if (!TURNPC.equals(Seleccion)) repe = false;

          }


         if (TURNPC.equals("1,1")){
          A= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         }else if (TURNPC.equals("1,2")){
                                          
                B= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                  }else if (TURNPC.equals("1,3")){
                                          
                C= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          }else if (TURNPC.equals("2,1")){
                                          
                D= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
            }
          else if (TURNPC.equals("2,2")){
                                          
                E= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }else if (TURNPC.equals("2,3")){
                                          
                F= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,1")){
                                          
                G= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,2")){
                                          
                H= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,3")){

                I= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }
                      if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Win");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}}
  
          else if (Seleccion.equals("1,2")){
              B = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                   PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
       
             if (TURNPC.equals(Seleccion))repe = true;
          while (repe){
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
              System.out.println("DESPUES while "+TURNPC );
         if (!TURNPC.equals(Seleccion)) repe = false;

          }


         if (TURNPC.equals("1,1")){
          A= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         }else if (TURNPC.equals("1,2")){
                                          
                B= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                  }else if (TURNPC.equals("1,3")){
                                          
                C= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          }else if (TURNPC.equals("2,1")){
                                          
                D= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
            }
          else if (TURNPC.equals("2,2")){
                                          
                E= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }else if (TURNPC.equals("2,3")){
                                          
                F= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,1")){
                                          
                G= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,2")){
                                          
                H= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,3")){

                I= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }
          }
    
          else if (Seleccion.equals("3,3")){
              I = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                   PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
       
             if (TURNPC.equals(Seleccion))repe = true;
          while (repe){
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
              System.out.println("DESPUES while "+TURNPC );
         if (!TURNPC.equals(Seleccion)) repe = false;

          }


         if (TURNPC.equals("1,1")){
          A= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         }else if (TURNPC.equals("1,2")){
                                          
                B= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                  }else if (TURNPC.equals("1,3")){
                                          
                C= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          }else if (TURNPC.equals("2,1")){
                                          
                D= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
            }
          else if (TURNPC.equals("2,2")){
                                          
                E= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }else if (TURNPC.equals("2,3")){
                                          
                F= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,1")){
                                          
                G= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,2")){
                                          
                H= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,3")){

                I= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }}
  
          else if (Seleccion.equals("1,2")){
              B = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          
          
         
    }            if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
         }
    }else if (!Inicio.equals("si"))
             System.out.println("bueno xd");
         }else {
              System.out.println("la maquina inicia");
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
                        while (TerminarJuego){
         PC = ( (int)(Math.random()*3)+1);
         PC2= ( (int)(Math.random()*3)+1);
         TURNPC = (PC + ","+ PC2) ;
                            System.out.println(TURNPC);
                
          
         if (TURNPC.equals("1,1")){
          A= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
         }else if (TURNPC.equals("1,2")){
                                          
                B= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                  }else if (TURNPC.equals("1,3")){
                                          
                C= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          
          }else if (TURNPC.equals("2,1")){
                                          
                D= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
            }
          else if (TURNPC.equals("2,2")){
                                          
                E= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           }else if (TURNPC.equals("2,3")){
                                          
                F= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,1")){
                                          
                G= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,2")){
                                          
                H= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
          }else if (TURNPC.equals("3,3")){

                I= "O";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");}
          if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
          Seleccion = input.nextLine();
          if (Seleccion.equals("Exit")){TerminarJuego = false;

          } else if (Seleccion.equals("1,1")){
             
              A = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
          
           }else if (Seleccion.equals("1,2")){
             
              B = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
         
           } else if (Seleccion.equals("1,3")){
             
              C = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
         
           }     else if (Seleccion.equals("2,1")){
             
              D = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
         
           } else if (Seleccion.equals("2,2")){
             
              E = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
         
           } else if (Seleccion.equals("2,3")){
             
              F = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
           if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
          
         
           } else if (Seleccion.equals("3,1")){
             
              G = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________"); if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
         
           } else if (Seleccion.equals("3,2")){
             
              H = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                      if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
         
           } else if (Seleccion.equals("3,3")){
             
              I = "X";
          System.out.println("____________");
          System.out.println(" | "+ A + " | " + B + " | "+ C + " | ");
          System.out.println("____________");
          System.out.println(" | "+ D + " | " + E + " | "+ F + " | ");
          System.out.println("____________");
          System.out.println(" | "+ G + " | " + H + " | "+ I + " | ");
          System.out.println("____________");
                     if(A == "X" && B == "X" && C == "X"){
                 System.out.println("You Win");
            }else if (A== "X" && E == "X" && I == "X"){
          System.out.println("You Win");}
            else if (A== "X" && D == "X" && G == "X"){
          System.out.println("You Win");}
            else if (B== "X" && E == "X" && H == "X"){
          System.out.println("You Win");}
            else if (C== "X" && F == "X" && I == "X"){
          System.out.println("You Win");}
            else if (C== "X" && E == "X" && G == "X"){
          System.out.println("You Win");}
            else if (D== "X" && E == "X" && F == "X"){
          System.out.println("You Win");}
            else if (G== "X" && H == "X" && I == "X"){
          System.out.println("You Win");}
            if(A == "O" && B == "O" && C == "O"){
                 System.out.println("You Loose");
                       }else if (A== "O" && E == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (A== "O" && D == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (B== "O" && E == "O" && H == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && F == "O" && I == "O"){
          System.out.println("You Loose");}
            else if (C== "O" && E == "O" && G == "O"){
          System.out.println("You Loose");}
            else if (D== "O" && E == "O" && F == "O"){
          System.out.println("You Loose");}
            else if (G== "O" && H == "O" && I == "O"){
          System.out.println("You loose");}
           } 
                        }
                        }
                        
          }}
             