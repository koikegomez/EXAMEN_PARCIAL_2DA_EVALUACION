import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		imprimirMensaje("----Imprima S para si y N para no----");
		if(escanear(scanner,"¿Tiene Fiebre?")){
			if(escanear(scanner, "¿Tose?")) {
				if (escanear(scanner,"¿Le cuesta respirar, resuella o tose con flemas?")) {
					imprimirMensaje("Posible Diagnostico:Neumonia o Infección de vias Respiratorias");
				}else { 
					if (escanear(scanner,"¿Le duele la cabeza?")) {
						imprimirMensaje("Posible Diagnostico:Infección Virica");
					}else {
						reusarPreguntas(scanner);
					}
				}
			}else {
				if(escanear(scanner,"¿Le duele la cabeza?")) {
					if (escanear(scanner,"¿Tiene alguno de los siguiente sintomas:dolor cuando inclina la cabeza,nausas,vomitos,molestia en los ojos ante la luz, somnolencia o confusion?")) {
					    imprimirMensaje("Posible Diagnostico:Meningitis");
					  }if (escanear(scanner,"¿Tiene vomito o diarrea?"));{
						  imprimirMensaje("Posible Diagnostico:Infeccion del tracto digestivo");
					  }
					  
				}else {
					reusarPreguntas(scanner);
				}
			}
		}else {
			imprimirMensaje("No se dispone de información suficiente para realizar un diagnostico");
		}
	}

	public static Boolean escanear(Scanner scanner, String mensaje) {
		Boolean blnCiclo=true,Result=true;
		do {
			imprimirMensaje(mensaje);
			String tmpString = scanner.next();
			switch (tmpString.toUpperCase()) {
			case "S":
			case "SI":
				Result = true;
				blnCiclo = !Result;
				break;
			case "N":
			case "NO":
				Result = false;
				blnCiclo = Result;
				break;
			default:
				imprimirMensaje("Opcion no valida vuelvalo a intentar");
				break;
			}				
		} while (blnCiclo);
		return Result;
	}
	
	public static void imprimirMensaje(String mensaje) {
		System.out.println(mensaje);
	}
	
	public static void reusarPreguntas(Scanner scanner) {
		if (escanear(scanner, "¿Le duelen los huesos o articulaciones?")) {
			imprimirMensaje("Posible Diagnostico:infeccion Virica");
		} else {
			if (escanear(scanner, "¿Presenta Erupciones Cutaneas?")) {
				imprimirMensaje("No se dispone de información suficiente para realizar un diagnostico");
			} else {
				if (escanear(scanner, "¿Le duele la garganta?")) {
					imprimirMensaje("Posible Diagnostico:infeccion de garganta");
				}else {
					if (escanear(scanner,"¿Le duele la espalda por encima de las lumbares, con escalofrios y fiebre?")) {
						imprimirMensaje	("Posible Diagostico:Infeccion Renal");
					}else {
						if (escanear(scanner,"¿Le duele al orinar o lo hace con frecuencia?")) {
							imprimirMensaje("Posible Diagnostico:Infeccion del tracto urinario");
						}else {
							if (escanear(scanner,"¿Ha pasado el dia al sol o con mucho calor?")) {
								imprimirMensaje("Posible Diagnostico:Golpe de Calor o Agotamiento por calor");
							}else imprimirMensaje("No se dispone de información suficiente para realizar un diagnostico");
						}
					}
				}
			}
		}
	}
}